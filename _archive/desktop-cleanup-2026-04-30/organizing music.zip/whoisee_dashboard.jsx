import { useState, useEffect } from "react";

const PURPLE = "#7B2FBE";
const CYAN = "#00D4FF";
const DARK = "#0D0720";
const DARK2 = "#1A0A2E";
const DARK3 = "#261040";
const MID = "#3D1A6E";
const LIGHT_PURPLE = "#B57BEE";
const GREEN = "#00E676";
const RED = "#FF3D57";
const AMBER = "#FFAB00";
const WHITE = "#F0E6FF";
const GREY = "#8B7BA8";

const style = {
  "@import": "https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;700;800&display=swap",
};

function GlowCard({ children, accent = PURPLE, style: s = {} }) {
  return (
    <div style={{
      background: `linear-gradient(145deg, ${DARK2}, ${DARK3})`,
      border: `1px solid ${accent}44`,
      borderRadius: 12,
      padding: "20px 22px",
      position: "relative",
      overflow: "hidden",
      boxShadow: `0 0 30px ${accent}18, inset 0 1px 0 ${accent}22`,
      ...s
    }}>
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0, height: 1,
        background: `linear-gradient(90deg, transparent, ${accent}88, transparent)`
      }} />
      {children}
    </div>
  );
}

function MetricBig({ label, value, sub, accent = CYAN, trend, trendVal }) {
  const tColor = trend === "up" ? GREEN : trend === "down" ? RED : AMBER;
  const tIcon = trend === "up" ? "▲" : trend === "down" ? "▼" : "◆";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: GREY, letterSpacing: 2, textTransform: "uppercase" }}>{label}</div>
      <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 36, fontWeight: 800, color: accent, lineHeight: 1, letterSpacing: -1 }}>{value}</div>
      {sub && <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: GREY }}>{sub}</div>}
      {trendVal && <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: tColor }}>{tIcon} {trendVal}</div>}
    </div>
  );
}

function ScoreBar({ label, value, max = 100, target, color = PURPLE, sublabel }) {
  const pct = Math.min((value / max) * 100, 100);
  const targetPct = target ? Math.min((target / max) * 100, 100) : null;
  const [animated, setAnimated] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setAnimated(pct), 100);
    return () => clearTimeout(t);
  }, [pct]);

  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }}>
        <div>
          <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: WHITE }}>{label}</span>
          {sublabel && <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, color: GREY, marginLeft: 8 }}>{sublabel}</span>}
        </div>
        <div style={{ display: "flex", gap: 12, alignItems: "baseline" }}>
          {target && <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, color: AMBER }}>target: {target}</span>}
          <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 18, fontWeight: 800, color: color }}>{value}</span>
        </div>
      </div>
      <div style={{ height: 6, background: "#ffffff12", borderRadius: 3, position: "relative", overflow: "visible" }}>
        <div style={{
          height: "100%", width: `${animated}%`, background: `linear-gradient(90deg, ${color}88, ${color})`,
          borderRadius: 3, transition: "width 1.2s cubic-bezier(0.4,0,0.2,1)",
          boxShadow: `0 0 10px ${color}66`
        }} />
        {targetPct && (
          <div style={{
            position: "absolute", top: -3, left: `${targetPct}%`,
            width: 2, height: 12, background: AMBER, borderRadius: 1,
            boxShadow: `0 0 6px ${AMBER}`
          }} />
        )}
      </div>
    </div>
  );
}

function ThresholdCard({ score, label, unlocks, why, timing, status }) {
  const colors = { locked: RED, close: AMBER, unlocked: GREEN };
  const bg = { locked: "#FF3D5714", close: "#FFAB0014", unlocked: "#00E67614" };
  const c = colors[status];
  const b = bg[status];
  const icon = status === "unlocked" ? "✓" : status === "close" ? "◈" : "○";
  return (
    <div style={{
      padding: "14px 16px",
      background: b,
      border: `1px solid ${c}44`,
      borderRadius: 10,
      marginBottom: 10,
      position: "relative",
      overflow: "hidden"
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 16, fontWeight: 700, color: c }}>{icon}</span>
          <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 15, fontWeight: 700, color: WHITE }}>{score}</span>
          <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, color: GREY, letterSpacing: 1, textTransform: "uppercase" }}>{label}</span>
        </div>
        <span style={{
          fontFamily: "'Space Mono', monospace", fontSize: 9, color: c,
          background: `${c}18`, padding: "3px 8px", borderRadius: 4, letterSpacing: 1
        }}>{status.toUpperCase()}</span>
      </div>
      <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: LIGHT_PURPLE, marginBottom: 4 }}>
        🔓 {unlocks}
      </div>
      <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, color: GREY, lineHeight: 1.6, marginBottom: 4 }}>{why}</div>
      <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, color: AMBER }}>⏱ {timing}</div>
    </div>
  );
}

function KPIRow({ metric, current, target, unit = "", trend, status }) {
  const sColor = status === "green" ? GREEN : status === "red" ? RED : AMBER;
  const sLabel = status === "green" ? "ON TRACK" : status === "red" ? "AT RISK" : "WATCH";
  const tIcon = trend === "up" ? "▲" : trend === "down" ? "▼" : "—";
  const tColor = trend === "up" ? GREEN : trend === "down" ? RED : GREY;
  return (
    <div style={{
      display: "grid", gridTemplateColumns: "1fr auto auto auto",
      gap: 16, alignItems: "center", padding: "12px 0",
      borderBottom: `1px solid ${DARK3}`
    }}>
      <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: WHITE }}>{metric}</div>
      <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 18, fontWeight: 700, color: CYAN, textAlign: "right" }}>
        {current}{unit}
      </div>
      <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, color: GREY, textAlign: "right" }}>
        → {target}{unit}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, color: tColor }}>{tIcon}</span>
        <span style={{
          fontFamily: "'Space Mono', monospace", fontSize: 9, color: sColor,
          background: `${sColor}18`, padding: "2px 8px", borderRadius: 3, letterSpacing: 1
        }}>{sLabel}</span>
      </div>
    </div>
  );
}

function BriefItem({ color, icon, text, sub }) {
  return (
    <div style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: `1px solid ${DARK3}` }}>
      <span style={{ fontSize: 16, flexShrink: 0, marginTop: 1 }}>{icon}</span>
      <div>
        <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: WHITE, lineHeight: 1.5 }}>{text}</div>
        {sub && <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, color: GREY, marginTop: 3 }}>{sub}</div>}
      </div>
    </div>
  );
}

function HiddenMetric({ label, value, tooltip, color = GREY }) {
  const [show, setShow] = useState(false);
  return (
    <div
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
      style={{ position: "relative", cursor: "help" }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", background: "#ffffff06", borderRadius: 8, marginBottom: 6, border: `1px solid ${color}22` }}>
        <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: GREY }}>{label}</span>
        <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 15, fontWeight: 700, color }}>{value}</span>
      </div>
      {show && tooltip && (
        <div style={{
          position: "absolute", bottom: "110%", left: 0, right: 0, zIndex: 99,
          background: DARK2, border: `1px solid ${PURPLE}44`, borderRadius: 8, padding: "10px 12px",
          fontFamily: "'Space Mono', monospace", fontSize: 10, color: LIGHT_PURPLE, lineHeight: 1.6,
          boxShadow: `0 0 20px ${PURPLE}44`
        }}>{tooltip}</div>
      )}
    </div>
  );
}

export default function WHOiSEEDashboard() {
  const [tab, setTab] = useState("overview");
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => setPulse(p => !p), 2000);
    return () => clearInterval(interval);
  }, []);

  const tabs = [
    { id: "overview", label: "OVERVIEW" },
    { id: "scores", label: "PS SCORES" },
    { id: "kpis", label: "KPIs" },
    { id: "brief", label: "BRIEF" },
  ];

  return (
    <div style={{
      minHeight: "100vh", background: DARK, color: WHITE, padding: "0",
      fontFamily: "'Space Mono', monospace",
      backgroundImage: `radial-gradient(ellipse at 20% 20%, ${PURPLE}18 0%, transparent 50%), radial-gradient(ellipse at 80% 80%, ${CYAN}0a 0%, transparent 50%)`
    }}>
      {/* HEADER */}
      <div style={{
        padding: "20px 28px 0",
        background: `linear-gradient(180deg, ${DARK2} 0%, transparent 100%)`,
        borderBottom: `1px solid ${PURPLE}33`,
        marginBottom: 0
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 32, fontWeight: 800, color: PURPLE, letterSpacing: -1 }}>WHO<span style={{ color: CYAN }}>i</span>SEE</span>
              <div style={{
                width: 8, height: 8, borderRadius: "50%", background: GREEN,
                boxShadow: `0 0 ${pulse ? "10px" : "4px"} ${GREEN}`,
                transition: "box-shadow 0.5s ease"
              }} />
              <span style={{ fontSize: 10, color: GREEN, letterSpacing: 2 }}>LIVE</span>
            </div>
            <div style={{ fontSize: 10, color: GREY, letterSpacing: 2, marginTop: 2 }}>DSP + SOCIAL INTELLIGENCE · MARCH 2026</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 10, color: GREY }}>Managed by</div>
            <div style={{ fontSize: 12, color: LIGHT_PURPLE, fontWeight: 700 }}>Thomas Nalian · TENx10</div>
            <div style={{ fontSize: 10, color: GREY, marginTop: 2 }}>Get Down · Kannibalen Records · March 4</div>
          </div>
        </div>
        {/* TABS */}
        <div style={{ display: "flex", gap: 0 }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              background: "none", border: "none", cursor: "pointer",
              padding: "10px 20px", fontSize: 10, letterSpacing: 2,
              fontFamily: "'Space Mono', monospace",
              color: tab === t.id ? CYAN : GREY,
              borderBottom: `2px solid ${tab === t.id ? CYAN : "transparent"}`,
              transition: "all 0.2s"
            }}>{t.label}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: "24px 28px" }}>

        {/* ═══ OVERVIEW TAB ═══ */}
        {tab === "overview" && (
          <div>
            {/* TOP STATS ROW */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 20 }}>
              <GlowCard accent={PURPLE}>
                <MetricBig label="Monthly Listeners" value="3–6K" sub="est. Feb 2026" accent={PURPLE} trend="up" trendVal="Get Down catalyst" />
              </GlowCard>
              <GlowCard accent={CYAN}>
                <MetricBig label="Artist PS" value="15–25" sub="est. range" accent={CYAN} trend="neutral" trendVal="Target: 30+" />
              </GlowCard>
              <GlowCard accent={GREEN}>
                <MetricBig label="Instagram" value="7,244" sub="@whoisee.music" accent={GREEN} trend="neutral" trendVal="+API needed" />
              </GlowCard>
              <GlowCard accent={AMBER}>
                <MetricBig label="Release Day" value="Mar 4" sub="Get Down · Day 0" accent={AMBER} trend="up" trendVal="72hr critical window" />
              </GlowCard>
            </div>

            {/* MIDDLE ROW */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
              {/* PLATFORM STATUS */}
              <GlowCard accent={PURPLE} style={{ gridColumn: "1" }}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 14, letterSpacing: 1 }}>PLATFORM STATUS</div>
                {[
                  { p: "Spotify for Artists", s: "✅ CONNECTED", c: GREEN, note: "Thomas has access" },
                  { p: "Instagram Graph API", s: "❌ NOT CONNECTED", c: RED, note: "Connect tonight — 3 min" },
                  { p: "TikTok Business", s: "❌ NOT SET UP", c: RED, note: "Required for automation" },
                  { p: "Apple Music for Artists", s: "❌ NOT REQUESTED", c: RED, note: "Brett requests tonight" },
                  { p: "Kannibalen Records", s: "✅ DISTRIBUTED", c: GREEN, note: "DM for channel support" },
                  { p: "SoundCloud", s: "⚠️ PARTIAL", c: AMBER, note: "On DirtySnatcha Records roster — verify standalone" },
                  { p: "Asset Library (Drive)", s: "⚠️ NOT CREATED", c: AMBER, note: "Create folder by March 7" },
                ].map((row, i) => (
                  <div key={i} style={{
                    display: "grid", gridTemplateColumns: "1fr auto", gap: 12, alignItems: "center",
                    padding: "8px 0", borderBottom: `1px solid ${DARK3}`
                  }}>
                    <div>
                      <div style={{ fontSize: 11, color: WHITE }}>{row.p}</div>
                      <div style={{ fontSize: 10, color: GREY, marginTop: 2 }}>{row.note}</div>
                    </div>
                    <div style={{ fontSize: 10, color: row.c, whiteSpace: "nowrap", textAlign: "right" }}>{row.s}</div>
                  </div>
                ))}
              </GlowCard>

              {/* UPCOMING SHOWS */}
              <GlowCard accent={CYAN}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 14, letterSpacing: 1 }}>UPCOMING SHOWS</div>
                {[
                  { show: "Pittsburgh · SideQuest", date: "Mar 14", days: "11 days", role: "Support DirtySnatcha", phase: "FINAL PUSH", c: RED },
                  { show: "Asbury Park", date: "Apr 24", days: "52 days", role: "Support DirtySnatcha · NJ/NYC", phase: "MAINTENANCE", c: AMBER },
                  { show: "Tucson · MAD 2026", date: "TBD", days: "TBD", role: "Support Hi I'm Ghost", phase: "ANNOUNCEMENT", c: PURPLE },
                ].map((row, i) => (
                  <div key={i} style={{ padding: "12px 0", borderBottom: `1px solid ${DARK3}` }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                      <span style={{ fontSize: 12, color: WHITE, fontWeight: 700 }}>{row.show}</span>
                      <span style={{ fontSize: 9, color: row.c, background: `${row.c}18`, padding: "2px 8px", borderRadius: 3, letterSpacing: 1 }}>{row.phase}</span>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ fontSize: 10, color: GREY }}>{row.role}</span>
                      <span style={{ fontSize: 11, color: row.c, fontFamily: "'Syne', sans-serif", fontWeight: 700 }}>{row.days}</span>
                    </div>
                  </div>
                ))}
                <div style={{ marginTop: 14, padding: "10px 14px", background: `${CYAN}12`, borderRadius: 8, border: `1px solid ${CYAN}22` }}>
                  <div style={{ fontSize: 10, color: CYAN, marginBottom: 4, letterSpacing: 1 }}>ALGORITHM IMPACT</div>
                  <div style={{ fontSize: 10, color: GREY, lineHeight: 1.6 }}>Pittsburgh geo-target → Shazam Spike · Run March 10–13 · Budget $50–75 · Goal: 50+ Shazams before show</div>
                </div>
              </GlowCard>
            </div>

            {/* RELEASE WINDOW ALERT */}
            <GlowCard accent={RED} style={{ marginBottom: 20 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 14, fontWeight: 800, color: RED, marginBottom: 6 }}>
                    🚨 72-HOUR CRITICAL WINDOW — GET DOWN
                  </div>
                  <div style={{ fontSize: 11, color: WHITE, lineHeight: 1.7 }}>
                    "Get Down" dropped March 4. What happens in the first 72 hours determines whether the algorithm pushes this to 100 people or 100,000. <span style={{ color: AMBER }}>Save-to-stream ratio, completion rate, and search volume are being measured RIGHT NOW.</span>
                  </div>
                </div>
                <div style={{ marginLeft: 24, flexShrink: 0, textAlign: "center" }}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 36, fontWeight: 800, color: RED }}>72</div>
                  <div style={{ fontSize: 9, color: GREY, letterSpacing: 2 }}>HRS LEFT</div>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 16 }}>
                {[
                  { action: "Toggle Discovery Mode ON", urgency: "NOW", who: "Thomas" },
                  { action: "Upload Canvas to Get Down in S4A", urgency: "TONIGHT", who: "Thomas" },
                  { action: "Launch Meta Save Campaign $50–75", urgency: "TODAY", who: "Thomas" },
                ].map((a, i) => (
                  <div key={i} style={{ padding: "10px 12px", background: `${RED}14`, borderRadius: 8, border: `1px solid ${RED}33` }}>
                    <div style={{ fontSize: 10, color: WHITE, marginBottom: 4 }}>{a.action}</div>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ fontSize: 9, color: RED, fontWeight: 700 }}>{a.urgency}</span>
                      <span style={{ fontSize: 9, color: GREY }}>{a.who}</span>
                    </div>
                  </div>
                ))}
              </div>
            </GlowCard>
          </div>
        )}

        {/* ═══ PS SCORES TAB ═══ */}
        {tab === "scores" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
              {/* ARTIST PS */}
              <GlowCard accent={PURPLE}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 4, letterSpacing: 1 }}>ARTIST POPULARITY SCORE</div>
                <div style={{ fontSize: 10, color: GREY, marginBottom: 16 }}>Drives test group size for every new release · Check: metrics.musicstax.com</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 16 }}>
                  <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 52, fontWeight: 800, color: PURPLE, lineHeight: 1 }}>15–25</span>
                  <div>
                    <div style={{ fontSize: 10, color: GREY }}>estimated</div>
                    <div style={{ fontSize: 10, color: AMBER }}>target: 30+</div>
                  </div>
                </div>
                <ScoreBar label="Current (est. min)" value={15} target={30} color={PURPLE} sublabel="verify Musicstax" />
                <ScoreBar label="Current (est. max)" value={25} target={30} color={LIGHT_PURPLE} />
                <ScoreBar label="Target — Q2 2026" value={40} color={CYAN} sublabel="6 months consistent execution" />
                <div style={{ marginTop: 16, padding: "12px 14px", background: `${PURPLE}14`, borderRadius: 8, border: `1px solid ${PURPLE}33` }}>
                  <div style={{ fontSize: 10, color: PURPLE, marginBottom: 6, letterSpacing: 1 }}>HOW ARTIST PS MOVES</div>
                  {["Search volume for 'WHOiSEE' on Spotify", "Follower growth rate", "Catalog save rate across all tracks", "Release cadence (6-week minimum rule)", "Monthly listener trend"].map((x, i) => (
                    <div key={i} style={{ fontSize: 10, color: GREY, padding: "3px 0", borderBottom: `1px solid ${DARK3}` }}>◈ {x}</div>
                  ))}
                </div>
              </GlowCard>

              {/* TRACK PS */}
              <GlowCard accent={CYAN}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 4, letterSpacing: 1 }}>TRACK PS — "GET DOWN"</div>
                <div style={{ fontSize: 10, color: GREY, marginBottom: 16 }}>ISRC-level score · Determines Release Radar + Discover Weekly placement</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 16 }}>
                  <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 52, fontWeight: 800, color: RED, lineHeight: 1 }}>?</span>
                  <div>
                    <div style={{ fontSize: 10, color: RED }}>CHECK NOW</div>
                    <div style={{ fontSize: 10, color: GREY }}>metrics.musicstax.com</div>
                  </div>
                </div>
                <div style={{ padding: "10px 14px", background: `${RED}12`, border: `1px solid ${RED}33`, borderRadius: 8, marginBottom: 16 }}>
                  <div style={{ fontSize: 11, color: RED, fontWeight: 700 }}>⚠ Day 0 — Score not yet checked</div>
                  <div style={{ fontSize: 10, color: GREY, marginTop: 4 }}>Open metrics.musicstax.com → search "Get Down WHOiSEE" → copy the number → update this dashboard</div>
                </div>
                <ScoreBar label="Target by Fri Mar 6 (Release Radar)" value={0} target={20} color={RED} sublabel="Release Radar refreshes Friday" />
                <ScoreBar label="Target by Mon Mar 9 (Discover Weekly)" value={0} target={30} color={AMBER} sublabel="Discover Weekly refreshes Monday" />
                <div style={{ marginTop: 16, padding: "12px 14px", background: `${CYAN}10`, borderRadius: 8, border: `1px solid ${CYAN}22` }}>
                  <div style={{ fontSize: 10, color: CYAN, marginBottom: 6, letterSpacing: 1 }}>WHAT MOVES TRACK PS</div>
                  {["Saves (weighted 3–5x vs stream)", "Completion rate (how many people finish the track)", "Skip rate (lower = better)", "Recent streams velocity (last 28 days)", "Playlist adds", "Shazam activity in local markets"].map((x, i) => (
                    <div key={i} style={{ fontSize: 10, color: GREY, padding: "3px 0", borderBottom: `1px solid ${DARK3}` }}>◈ {x}</div>
                  ))}
                </div>
              </GlowCard>
            </div>

            {/* THRESHOLD MAP */}
            <GlowCard accent={AMBER} style={{ marginBottom: 20 }}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 4, letterSpacing: 1 }}>THRESHOLD MAP — WHAT EACH SCORE UNLOCKS</div>
              <div style={{ fontSize: 10, color: GREY, marginBottom: 16 }}>These are the exact numbers WHOiSEE needs to cross. Every ad dollar and social post should be oriented around reaching these thresholds at the right moment.</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <ThresholdCard score="Track 20+" label="RELEASE RADAR" unlocks="Release Radar for non-followers" why="'Get Down' starts appearing in playlists for people who've never heard of WHOiSEE. Below 20, only existing followers see it." timing="Release Radar refreshes FRIDAY. Push hard before March 6." status="locked" />
                <ThresholdCard score="Track 30+" label="DISCOVER WEEKLY" unlocks="Discover Weekly placement" why="The major unlock. Spotify inserts 'Get Down' into Discover Weekly for listeners who match WHOiSEE's sound profile. This is where streams compound." timing="Discover Weekly refreshes MONDAY. Maximum push before March 9 if approaching 30." status="locked" />
                <ThresholdCard score="Artist 30+" label="1K TEST GROUP" unlocks="~1,000+ test listeners per new release" why="Current est. Artist PS: 15–25. Cross 30 and every future release gets 3–10x the initial algorithmic reach. This is the compound multiplier." timing="Cumulative — driven by consistent release cadence + saves + search. 'Get Down' can push this significantly." status="close" />
                <ThresholdCard score="Artist 40+" label="5K TEST GROUP" unlocks="~5,000 test listeners · Radio/Mix playlist likely" why="At 40+ WHOiSEE enters the next tier of bass music algorithmic ecosystem. Q2 2026 target if 'Get Down' fires correctly." timing="3–6 months of consistent execution from current position." status="locked" />
              </div>
            </GlowCard>

            {/* HIDDEN METRICS */}
            <GlowCard accent={GREY}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 4, letterSpacing: 1 }}>HIDDEN SPOTIFY METRICS</div>
              <div style={{ fontSize: 10, color: GREY, marginBottom: 16 }}>These signals are not visible in Spotify for Artists but ARE visible to the algorithm. Hover each for context.</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 8 }}>
                <HiddenMetric label="Save-to-Stream Ratio" value="⚠ Unknown" color={AMBER} tooltip="Target: 10%+ saves vs streams. Below 5% = wrong ad audience. Check in S4A Analytics. This is the #1 Track PS driver." />
                <HiddenMetric label="Track Completion Rate" value="⚠ Unknown" color={AMBER} tooltip="% of listeners who play the track to end. High completion = algorithm treats it as high quality. First 15 seconds are critical — must hook immediately." />
                <HiddenMetric label="Skip Rate" value="⚠ Unknown" color={AMBER} tooltip="Lower is better. High skip rate (especially in first 30 seconds) tanks Track PS fast. Canvas loops reduce skip rate by ~8–12%." />
                <HiddenMetric label="Playlist Add Rate" value="⚠ Unknown" color={AMBER} tooltip="Personal playlist adds (not editorial) are a major Artist PS signal. CTA: 'Add Get Down to your playlist' in every post." />
                <HiddenMetric label="Search Volume (Artist Name)" value="⚠ Unknown" color={PURPLE} tooltip="Spotify search for 'WHOiSEE' directly boosts Artist PS. This is why 'Search WHOiSEE on Spotify' CTAs are in every post — it's a direct algorithm input." />
                <HiddenMetric label="Shazam Count" value="0 baseline" color={PURPLE} tooltip="Shazam data feeds into both Spotify and Apple Music algorithms. Pittsburgh Shazam Spike campaign (March 10–13) targets 50+ Shazams in local market." />
                <HiddenMetric label="Algorithmic Test Group Size" value="~100–300" color={CYAN} tooltip="Estimated based on Artist PS 15–25. This is how many people Spotify tests 'Get Down' with on release. Grows to 1,000+ at Artist PS 30, 5,000+ at Artist PS 40." />
                <HiddenMetric label="Discovery Mode Boost" value="❌ OFF — TURN ON" color={RED} tooltip="Discovery Mode allows Spotify to promote 'Get Down' in radio and autoplay in exchange for a small royalty reduction. MUST be enabled before first 72 hours. Thomas: turn this on NOW in S4A." />
                <HiddenMetric label="Canvas Active" value="❌ Not uploaded" color={RED} tooltip="Animated loop visual for Spotify mobile. Reduces skip rate, increases save rate, increases share rate. Takes 5 minutes to upload in S4A. Do it tonight." />
                <HiddenMetric label="Artist Audio Message" value="❌ Not recorded" color={AMBER} tooltip="Spotify feature: record a 30-second voice message for followers. Appears in Spotify notification. Brett records tonight. Drives first-day saves significantly." />
              </div>
              <div style={{ marginTop: 16, padding: "12px 14px", background: `${GREY}0a`, borderRadius: 8, border: `1px solid ${GREY}22` }}>
                <div style={{ fontSize: 10, color: GREY, lineHeight: 1.7 }}>
                  <span style={{ color: WHITE }}>Note on Popularity Scores:</span> The Popularity Score (PS) is NOT visible in the Spotify for Artists dashboard. It lives in the Spotify Developer API. To check it: <span style={{ color: CYAN }}>metrics.musicstax.com</span> (free), <span style={{ color: CYAN }}>submithub.com/popularity-checker</span> (free), or <span style={{ color: CYAN }}>artist.tools</span> (freemium). Check daily for the first 14 days after release.
                </div>
              </div>
            </GlowCard>
          </div>
        )}

        {/* ═══ KPIs TAB ═══ */}
        {tab === "kpis" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
              <GlowCard accent={CYAN}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 14, letterSpacing: 1 }}>30-DAY KPI TARGETS · MARCH 2026</div>
                <KPIRow metric="Spotify Monthly Listeners" current="3–6K" target="8–12K" trend="up" status="watch" />
                <KPIRow metric="Artist Popularity Score" current="15–25" target="30+" trend="neutral" status="watch" />
                <KPIRow metric="Track PS — Get Down" current="?" target="25–35" trend="neutral" status="red" />
                <KPIRow metric="Instagram Followers" current="7,244" target="8,500+" trend="neutral" status="watch" />
                <KPIRow metric="Instagram Engagement Rate" current="?" target="3–5%" trend="neutral" status="red" />
                <KPIRow metric="Save-to-Stream Ratio" current="?" target="10%+" trend="neutral" status="red" />
                <KPIRow metric="Shazams (Pittsburgh market)" current="0" target="50+" trend="neutral" status="red" />
                <KPIRow metric="Next Release Locked" current="TBD" target="By Apr 15" trend="neutral" status="watch" />
              </GlowCard>

              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <GlowCard accent={GREEN}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 12, letterSpacing: 1 }}>NEXT 9 ACTIONS — PRIORITIZED</div>
                  {[
                    { n: 1, who: "Thomas", when: "NOW", text: "Check Track PS on Musicstax", c: RED },
                    { n: 2, who: "Thomas", when: "TONIGHT", text: "Toggle Discovery Mode ON for Get Down in S4A", c: RED },
                    { n: 3, who: "Thomas", when: "TONIGHT", text: "Complete all 7 free DSP checklist actions", c: RED },
                    { n: 4, who: "Thomas", when: "TODAY", text: "Launch Meta Save Campaign $50–75", c: RED },
                    { n: 5, who: "Brett", when: "TONIGHT", text: "Request Apple Music for Artists access", c: RED },
                    { n: 6, who: "Thomas", when: "Mar 6", text: "Lock next single (April 10 drop — 6-week rule)", c: AMBER },
                    { n: 7, who: "Thomas", when: "Daily", text: "Check Track PS on Musicstax March 4–10", c: AMBER },
                    { n: 8, who: "Thomas", when: "Mar 10", text: "Launch Pittsburgh Shazam Spike $50–75", c: AMBER },
                    { n: 9, who: "Brett+T", when: "Mar 7", text: "Create WHOiSEE Assets Google Drive folder", c: GREY },
                  ].map((a, i) => (
                    <div key={i} style={{ display: "flex", gap: 10, padding: "8px 0", borderBottom: `1px solid ${DARK3}`, alignItems: "flex-start" }}>
                      <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 14, fontWeight: 800, color: a.c, flexShrink: 0, width: 20 }}>{a.n}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 11, color: WHITE }}>{a.text}</div>
                        <div style={{ display: "flex", gap: 8, marginTop: 2 }}>
                          <span style={{ fontSize: 9, color: a.c }}>{a.when}</span>
                          <span style={{ fontSize: 9, color: GREY }}>{a.who}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </GlowCard>

                <GlowCard accent={AMBER}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 12, letterSpacing: 1 }}>AD BUDGET PLAN</div>
                  {[
                    { item: "Meta Save Campaign (Get Down)", budget: "$50–75", when: "March 4–7", status: "LAUNCH NOW" },
                    { item: "Pittsburgh Shazam Spike", budget: "$50–75", when: "March 10–13", status: "SCHEDULE" },
                    { item: "Tucson/MAD 2026 Shazam Spike", budget: "$50–75", when: "TBD", status: "PENDING DATE" },
                    { item: "Asbury Park Shazam Spike", budget: "$50–75", when: "Apr 17–23", status: "PLAN AHEAD" },
                  ].map((row, i) => (
                    <div key={i} style={{ padding: "9px 0", borderBottom: `1px solid ${DARK3}` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 2 }}>
                        <span style={{ fontSize: 11, color: WHITE }}>{row.item}</span>
                        <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 14, fontWeight: 700, color: CYAN }}>{row.budget}</span>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <span style={{ fontSize: 10, color: GREY }}>{row.when}</span>
                        <span style={{ fontSize: 9, color: AMBER, letterSpacing: 1 }}>{row.status}</span>
                      </div>
                    </div>
                  ))}
                  <div style={{ marginTop: 12, padding: "10px", background: `${CYAN}0a`, borderRadius: 8, display: "flex", justifyContent: "space-between" }}>
                    <span style={{ fontSize: 11, color: WHITE }}>TOTAL ESTIMATED</span>
                    <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 18, fontWeight: 800, color: CYAN }}>$200–300</span>
                  </div>
                </GlowCard>
              </div>
            </div>

            {/* 6-WEEK CADENCE RULE */}
            <GlowCard accent={PURPLE}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: WHITE, marginBottom: 4, letterSpacing: 1 }}>RELEASE CADENCE · 6-WEEK RULE</div>
              <div style={{ fontSize: 10, color: GREY, marginBottom: 16 }}>Artist PS begins decaying if no new ISRC is released within 6 weeks of the previous release. "Get Down" = March 4. Next ISRC deadline: April 15.</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 4 }}>
                {["W1\nMar 4", "W2\nMar 11", "W3\nMar 18", "W4\nMar 25", "W5\nApr 1", "W6\nApr 8"].map((w, i) => {
                  const done = i < 1;
                  const deadline = i === 5;
                  return (
                    <div key={i} style={{
                      padding: "10px 8px", borderRadius: 8, textAlign: "center",
                      background: done ? `${GREEN}22` : deadline ? `${RED}22` : `${PURPLE}11`,
                      border: `1px solid ${done ? GREEN : deadline ? RED : PURPLE}33`
                    }}>
                      <div style={{ fontSize: 9, color: done ? GREEN : deadline ? RED : GREY, fontFamily: "'Space Mono', monospace", whiteSpace: "pre", lineHeight: 1.5 }}>{w}</div>
                      {done && <div style={{ fontSize: 9, color: GREEN, marginTop: 4 }}>✓ LIVE</div>}
                      {deadline && <div style={{ fontSize: 9, color: RED, marginTop: 4 }}>DEADLINE</div>}
                    </div>
                  );
                })}
              </div>
              <div style={{ marginTop: 12, display: "flex", justifyContent: "space-between", fontSize: 10, color: GREY }}>
                <span>Get Down released: <span style={{ color: GREEN }}>March 4</span></span>
                <span>Next ISRC deadline: <span style={{ color: RED }}>April 15</span></span>
                <span>Lock next single by: <span style={{ color: AMBER }}>March 6</span></span>
                <span>Upload to VMG by: <span style={{ color: AMBER }}>March 10</span></span>
              </div>
            </GlowCard>
          </div>
        )}

        {/* ═══ BRIEF TAB ═══ */}
        {tab === "brief" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <GlowCard accent={RED}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 800, color: RED, marginBottom: 12, letterSpacing: 1 }}>🔴 URGENT — DO TODAY</div>
                  <BriefItem color={RED} icon="🔴" text="Check 'Get Down' Track PS on Musicstax RIGHT NOW" sub="metrics.musicstax.com — what is the number? This changes everything." />
                  <BriefItem color={RED} icon="🔴" text="Toggle Discovery Mode ON in Spotify for Artists before midnight" sub="Thomas: settings in S4A → Get Down → toggle ON. 2 minutes." />
                  <BriefItem color={RED} icon="🔴" text="Complete all 7 free DSP checklist actions today" sub="Canvas upload, Audio Message, SoundCloud post, Pandora AAM, Alexa CTA, TikTok Sound, Clips" />
                  <BriefItem color={RED} icon="🔴" text="Launch Meta Save Campaign $50–75 targeting bass fans" sub="Pittsburgh, Tucson, NJ markets. CTA: 'Add to library' not 'listen now'" />
                  <BriefItem color={RED} icon="🔴" text="Brett requests Apple Music for Artists at artists.apple.com" sub="5 minutes. Shazam for Artists feeds Apple Music editorial." />
                </GlowCard>

                <GlowCard accent={AMBER}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 800, color: AMBER, marginBottom: 12, letterSpacing: 1 }}>🟡 THIS WEEK</div>
                  <BriefItem color={AMBER} icon="🟡" text="Lock next single by March 6 (Thomas + Lee)" sub="April 10 target drop date. Upload to VMG by March 10. 6-week rule: no new ISRC by April 15 = Artist PS decay." />
                  <BriefItem color={AMBER} icon="🟡" text="Check Track PS daily March 5–9. Increase spend if approaching 30." sub="If PS is 24–28 by Thursday → maximum push before Monday Discover Weekly refresh" />
                  <BriefItem color={AMBER} icon="🟡" text="Pittsburgh Shazam Spike — schedule now, launch March 10" sub="$50–75 · Pittsburgh 15-mile radius · 'WHAT TRACK IS THIS? 🛸' no title shown" />
                  <BriefItem color={AMBER} icon="🟡" text="Create WHOiSEE Assets Google Drive folder by March 7" sub="Brett uploads all photos + videos. Platform ingests on API connection." />
                </GlowCard>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <GlowCard accent={CYAN}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 800, color: CYAN, marginBottom: 12, letterSpacing: 1 }}>📱 CONTENT TODAY · MARCH 4</div>
                  {[
                    { platform: "IG / FB / X", type: "ANNOUNCEMENT", text: "GET DOWN 🛸 WHOiSEE x @hiimghostsound — out now on @kannibalen_records. go run it up — link in bio 🔗", priority: "HIGH" },
                    { platform: "IG Stories", type: "SEARCH CTA", text: "Search 'WHOiSEE' on Spotify 🛸 — Get Down is out right now", priority: "HIGH" },
                    { platform: "TikTok", type: "AUDIO CLIP", text: "First 15 seconds — hardest drop. No track name shown. Force Shazam.", priority: "HIGH" },
                  ].map((c, i) => (
                    <div key={i} style={{ padding: "12px 0", borderBottom: `1px solid ${DARK3}` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <span style={{ fontSize: 10, color: CYAN, background: `${CYAN}18`, padding: "2px 8px", borderRadius: 3 }}>{c.platform}</span>
                          <span style={{ fontSize: 9, color: GREY, letterSpacing: 1 }}>{c.type}</span>
                        </div>
                        <span style={{ fontSize: 9, color: RED, letterSpacing: 1 }}>{c.priority}</span>
                      </div>
                      <div style={{ fontSize: 11, color: WHITE, lineHeight: 1.6, fontStyle: "italic" }}>"{c.text}"</div>
                    </div>
                  ))}
                </GlowCard>

                <GlowCard accent={GREEN}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 800, color: GREEN, marginBottom: 12, letterSpacing: 1 }}>📊 METRICS CHECK</div>
                  {[
                    { label: "Spotify Monthly Listeners", value: "~3–6K", note: "Verify in S4A" },
                    { label: "Artist Popularity Score", value: "15–25 est.", note: "Target: 30+" },
                    { label: "Track PS — Get Down", value: "CHECK NOW", note: "metrics.musicstax.com" },
                    { label: "Instagram Followers", value: "7,244", note: "@whoisee.music" },
                    { label: "Instagram Engagement", value: "⚠ Unknown", note: "Connect API to see" },
                    { label: "Save-to-Stream Ratio", value: "⚠ Unknown", note: "Target: 10%+" },
                    { label: "Kannibalen · Get Down release", value: "Day 0", note: "March 4, 2026" },
                    { label: "Hi I'm Ghost (collab)", value: "100.7K ML", note: "Exposure multiplier" },
                  ].map((m, i) => (
                    <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${DARK3}` }}>
                      <div>
                        <div style={{ fontSize: 11, color: WHITE }}>{m.label}</div>
                        <div style={{ fontSize: 9, color: GREY }}>{m.note}</div>
                      </div>
                      <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 14, fontWeight: 700, color: CYAN, textAlign: "right" }}>{m.value}</div>
                    </div>
                  ))}
                </GlowCard>

                <GlowCard accent={PURPLE}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 800, color: PURPLE, marginBottom: 10, letterSpacing: 1 }}>💡 STRATEGIC RECOMMENDATION</div>
                  <div style={{ fontSize: 12, color: WHITE, lineHeight: 1.8, marginBottom: 12 }}>
                    <span style={{ color: CYAN }}>The Hi I'm Ghost collab is the biggest release moment WHOiSEE has had.</span> 100.7K monthly listeners on Kannibalen Records — if even 1% of their audience saves "Get Down" that's 1,000 saves in week 1, which would spike Track PS past 30 and Artist PS past 30 <em>simultaneously</em>.
                  </div>
                  <div style={{ fontSize: 12, color: WHITE, lineHeight: 1.8, marginBottom: 12 }}>
                    The Facebook post has 4 likes. That means the organic push isn't happening on its own. <span style={{ color: RED }}>The $50–75 save campaign and the 7 free DSP actions are not optional — they're the difference between this track dying in the algorithm and compounding for 4 weeks.</span>
                  </div>
                  <div style={{ padding: "12px 14px", background: `${PURPLE}18`, borderRadius: 8, border: `1px solid ${PURPLE}44` }}>
                    <div style={{ fontSize: 11, color: PURPLE, letterSpacing: 1, marginBottom: 6 }}>CTA — DO THIS NOW</div>
                    <div style={{ fontSize: 11, color: WHITE, lineHeight: 1.7 }}>Thomas: open S4A, toggle Discovery Mode ON for Get Down, then open Musicstax and get the Track PS number. Text it to Brett. That number changes what you do in the next 72 hours. <span style={{ color: AMBER }}>Do it before midnight.</span></div>
                  </div>
                </GlowCard>
              </div>
            </div>
          </div>
        )}

        {/* FOOTER */}
        <div style={{ marginTop: 24, paddingTop: 16, borderTop: `1px solid ${DARK3}`, display: "flex", justifyContent: "space-between", fontSize: 9, color: GREY, letterSpacing: 1 }}>
          <span>TENx10 · WHOiSEE INTELLIGENCE DASHBOARD · MARCH 2026</span>
          <span>thomas@dirtysnatcha.com · 248-765-1997</span>
        </div>
      </div>
    </div>
  );
}
