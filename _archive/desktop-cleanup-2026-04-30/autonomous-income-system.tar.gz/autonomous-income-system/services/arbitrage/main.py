"""
Service Arbitrage Agent
Monitors Upwork/Fiverr for AI automation gigs, auto-delivers using AI
Target: $230/month in 2-4 months
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import List, Dict
import asyncpg
import aioredis
from anthropic import AsyncAnthropic
import httpx

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ArbitrageAgent:
    def __init__(self, config: Dict):
        self.config = config
        self.anthropic = AsyncAnthropic(api_key=config['anthropic_api_key'])
        self.db_pool = None
        self.redis = None
        
    async def initialize(self):
        """Initialize database and Redis connections"""
        self.db_pool = await asyncpg.create_pool(self.config['database_url'])
        self.redis = await aioredis.create_redis_pool(self.config['redis_url'])
        await self.setup_database()
        
    async def setup_database(self):
        """Create necessary tables"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS gigs (
                    id SERIAL PRIMARY KEY,
                    platform VARCHAR(50),
                    gig_id VARCHAR(255) UNIQUE,
                    title TEXT,
                    description TEXT,
                    budget_min DECIMAL,
                    budget_max DECIMAL,
                    client_info JSONB,
                    discovered_at TIMESTAMP DEFAULT NOW(),
                    status VARCHAR(50) DEFAULT 'discovered',
                    bid_amount DECIMAL,
                    bid_proposal TEXT,
                    won_at TIMESTAMP,
                    delivered_at TIMESTAMP,
                    revenue DECIMAL,
                    ai_cost DECIMAL,
                    net_profit DECIMAL
                )
            """)
            
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS deliverables (
                    id SERIAL PRIMARY KEY,
                    gig_id INTEGER REFERENCES gigs(id),
                    deliverable_type VARCHAR(100),
                    content TEXT,
                    generated_at TIMESTAMP DEFAULT NOW(),
                    approved BOOLEAN DEFAULT FALSE
                )
            """)
    
    async def monitor_upwork(self):
        """Monitor Upwork RSS feed for AI automation gigs"""
        logger.info("Monitoring Upwork for AI automation opportunities...")
        
        # Upwork RSS feeds (free, no API key needed for monitoring)
        search_terms = [
            "AI automation",
            "chatbot development",
            "AI workflow",
            "claude api integration",
            "openai integration",
            "ai assistant development"
        ]
        
        for term in search_terms:
            rss_url = f"https://www.upwork.com/ab/feed/jobs/rss?q={term.replace(' ', '+')}&sort=recency"
            
            try:
                async with httpx.AsyncClient() as client:
                    response = await client.get(rss_url, timeout=10.0)
                    
                    if response.status_code == 200:
                        gigs = await self.parse_upwork_rss(response.text)
                        await self.process_discovered_gigs(gigs, 'upwork')
                        
            except Exception as e:
                logger.error(f"Error monitoring Upwork for '{term}': {e}")
            
            await asyncio.sleep(5)  # Rate limiting
    
    async def parse_upwork_rss(self, rss_content: str) -> List[Dict]:
        """Parse Upwork RSS feed"""
        # Use AI to parse RSS (simpler than XML parsing)
        message = await self.anthropic.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[{
                "role": "user",
                "content": f"""Parse this Upwork RSS feed and extract gigs. Return JSON array with:
                - gig_id (from link)
                - title
                - description
                - budget (extract from description)
                - posted_date
                
                RSS content:
                {rss_content[:4000]}
                
                Return ONLY valid JSON array, no markdown.
                """
            }]
        )
        
        try:
            return json.loads(message.content[0].text)
        except:
            logger.error("Failed to parse RSS response")
            return []
    
    async def process_discovered_gigs(self, gigs: List[Dict], platform: str):
        """Process newly discovered gigs"""
        for gig in gigs:
            try:
                # Check if we've seen this gig before
                async with self.db_pool.acquire() as conn:
                    exists = await conn.fetchval(
                        "SELECT id FROM gigs WHERE gig_id = $1",
                        gig['gig_id']
                    )
                    
                    if not exists:
                        # Analyze if this is a good fit
                        should_bid, analysis = await self.analyze_gig(gig)
                        
                        if should_bid:
                            # Store gig
                            gig_db_id = await conn.fetchval("""
                                INSERT INTO gigs (platform, gig_id, title, description, 
                                                budget_min, budget_max, client_info, status)
                                VALUES ($1, $2, $3, $4, $5, $6, $7, 'ready_to_bid')
                                RETURNING id
                            """, platform, gig['gig_id'], gig['title'], 
                               gig['description'], gig.get('budget_min', 0),
                               gig.get('budget_max', 0), json.dumps({}))
                            
                            logger.info(f"New opportunity: {gig['title'][:50]}... (ID: {gig_db_id})")
                            
                            # Add to bidding queue
                            await self.redis.rpush('bid_queue', str(gig_db_id))
                            
            except Exception as e:
                logger.error(f"Error processing gig: {e}")
    
    async def analyze_gig(self, gig: Dict) -> tuple[bool, Dict]:
        """Use AI to analyze if gig is a good fit"""
        message = await self.anthropic.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{
                "role": "user",
                "content": f"""Analyze this freelance gig for AI service arbitrage viability.

GIG DETAILS:
Title: {gig['title']}
Description: {gig['description'][:500]}
Budget: ${gig.get('budget_min', 0)}-${gig.get('budget_max', 0)}

CRITERIA:
1. Can be delivered primarily using AI tools (Claude, GPT, automation)
2. Budget is at least $75
3. Scope is clear and deliverable within 5-10 hours work
4. Not requesting custom ML models or specialized AI knowledge
5. Deliverable: chatbot, workflow automation, content system, or similar

Return JSON:
{{
    "should_bid": true/false,
    "confidence": 0-100,
    "estimated_ai_cost": dollar amount,
    "estimated_hours": hours,
    "reasoning": "brief explanation",
    "suggested_bid": dollar amount
}}
"""
            }]
        )
        
        try:
            analysis = json.loads(message.content[0].text)
            return analysis['should_bid'], analysis
        except:
            return False, {}
    
    async def generate_bid_proposal(self, gig_id: int) -> str:
        """Generate winning bid proposal"""
        async with self.db_pool.acquire() as conn:
            gig = await conn.fetchrow(
                "SELECT * FROM gigs WHERE id = $1",
                gig_id
            )
        
        message = await self.anthropic.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=800,
            messages=[{
                "role": "user",
                "content": f"""Write a winning Upwork proposal for this gig.

TITLE: {gig['title']}
DESCRIPTION: {gig['description']}
BUDGET: ${gig['budget_min']}-${gig['budget_max']}

REQUIREMENTS:
- Professional but casual tone
- Demonstrate specific AI automation expertise
- Mention relevant tools (Claude API, n8n, Make, Zapier alternatives)
- Clear timeline (usually 3-7 days)
- Ask 1-2 qualifying questions
- Keep under 150 words
- NO generic phrases like "I'm interested" or "I'm a perfect fit"
- Start with addressing their specific need

Return ONLY the proposal text, no JSON.
"""
            }]
        )
        
        proposal = message.content[0].text
        
        # Store proposal
        async with self.db_pool.acquire() as conn:
            await conn.execute(
                "UPDATE gigs SET bid_proposal = $1, status = 'bid_sent' WHERE id = $2",
                proposal, gig_id
            )
        
        return proposal
    
    async def deliver_work(self, gig_id: int):
        """Use AI to deliver the actual work"""
        logger.info(f"Starting delivery for gig {gig_id}")
        
        async with self.db_pool.acquire() as conn:
            gig = await conn.fetchrow(
                "SELECT * FROM gigs WHERE id = $1",
                gig_id
            )
        
        # Determine delivery type from description
        message = await self.anthropic.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[{
                "role": "user",
                "content": f"""Client hired us for: {gig['title']}

Full requirements: {gig['description']}

What deliverable type is this? Return JSON:
{{
    "type": "chatbot" | "workflow_automation" | "content_system" | "api_integration",
    "specific_requirements": ["list", "of", "requirements"],
    "suggested_approach": "how to deliver this using AI tools"
}}
"""
            }]
        )
        
        delivery_plan = json.loads(message.content[0].text)
        
        # Generate the actual deliverable based on type
        if delivery_plan['type'] == 'chatbot':
            deliverable = await self.build_chatbot(gig, delivery_plan)
        elif delivery_plan['type'] == 'workflow_automation':
            deliverable = await self.build_workflow(gig, delivery_plan)
        elif delivery_plan['type'] == 'content_system':
            deliverable = await self.build_content_system(gig, delivery_plan)
        else:
            deliverable = await self.build_generic_solution(gig, delivery_plan)
        
        # Store deliverable
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO deliverables (gig_id, deliverable_type, content)
                VALUES ($1, $2, $3)
            """, gig_id, delivery_plan['type'], json.dumps(deliverable))
            
            await conn.execute(
                "UPDATE gigs SET status = 'delivered', delivered_at = NOW() WHERE id = $1",
                gig_id
            )
        
        logger.info(f"Delivered {delivery_plan['type']} for gig {gig_id}")
        
        return deliverable
    
    async def build_chatbot(self, gig: Dict, plan: Dict) -> Dict:
        """Build a custom chatbot using Claude API"""
        message = await self.anthropic.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[{
                "role": "user",
                "content": f"""Generate complete code for a chatbot that meets these requirements:

CLIENT NEEDS: {gig['description']}
REQUIREMENTS: {json.dumps(plan['specific_requirements'])}

Generate:
1. HTML/JavaScript chatbot widget (single file, embedded)
2. Backend Python Flask API that uses Claude API
3. Deployment instructions
4. Environment variables needed

Return JSON:
{{
    "widget_code": "complete HTML/JS code",
    "backend_code": "complete Python Flask code", 
    "deployment_instructions": "step by step",
    "env_vars": ["list of needed vars"]
}}
"""
            }]
        )
        
        return json.loads(message.content[0].text)
    
    async def build_workflow(self, gig: Dict, plan: Dict) -> Dict:
        """Build n8n workflow automation"""
        message = await self.anthropic.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[{
                "role": "user",
                "content": f"""Generate an n8n workflow JSON that automates:

CLIENT NEEDS: {gig['description']}
REQUIREMENTS: {json.dumps(plan['specific_requirements'])}

Create complete n8n workflow with:
- Trigger node
- Processing nodes
- AI integration (Claude/GPT)
- Output/notification nodes

Return valid n8n workflow JSON.
"""
            }]
        )
        
        return {
            "workflow_json": message.content[0].text,
            "setup_instructions": "Import into n8n, configure credentials"
        }
    
    async def build_content_system(self, gig: Dict, plan: Dict) -> Dict:
        """Build automated content generation system"""
        # Similar pattern - use AI to generate the system
        return {
            "system_type": "content_automation",
            "code": "generated_code",
            "instructions": "setup_steps"
        }
    
    async def build_generic_solution(self, gig: Dict, plan: Dict) -> Dict:
        """Build generic AI-powered solution"""
        return {
            "solution_type": "custom",
            "approach": plan['suggested_approach']
        }
    
    async def run_bidding_loop(self):
        """Process bid queue"""
        while True:
            try:
                gig_id = await self.redis.blpop('bid_queue', timeout=5)
                if gig_id:
                    gig_id = int(gig_id[1].decode())
                    proposal = await self.generate_bid_proposal(gig_id)
                    logger.info(f"Generated proposal for gig {gig_id}")
                    
                    # In production, you'd actually submit via Upwork API
                    # For now, we log it for manual submission
                    logger.info(f"PROPOSAL:\n{proposal}")
                    
            except Exception as e:
                logger.error(f"Error in bidding loop: {e}")
                await asyncio.sleep(5)
    
    async def run(self):
        """Main agent loop"""
        await self.initialize()
        
        # Run monitoring and bidding concurrently
        await asyncio.gather(
            self.monitor_upwork(),
            self.run_bidding_loop()
        )

if __name__ == "__main__":
    import os
    
    config = {
        'database_url': os.getenv('DATABASE_URL'),
        'redis_url': os.getenv('REDIS_URL'),
        'anthropic_api_key': os.getenv('ANTHROPIC_API_KEY'),
        'openai_api_key': os.getenv('OPENAI_API_KEY'),
    }
    
    agent = ArbitrageAgent(config)
    asyncio.run(agent.run())
