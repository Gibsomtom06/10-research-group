'use client';

import { useEffect, useState } from 'react';

interface Stats {
  total_revenue: number;
  monthly_revenue: number;
  active_gigs: number;
  active_products: number;
  total_mrr: number;
  profit_margin: number;
}

interface Gig {
  id: number;
  title: string;
  status: string;
  budget_max: number;
  platform: string;
}

interface Product {
  id: number;
  name: string;
  mrr: number;
  customers: number;
  status: string;
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [gigs, setGigs] = useState<Gig[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    try {
      const [statsRes, gigsRes, productsRes] = await Promise.all([
        fetch('/api/stats'),
        fetch('/api/gigs'),
        fetch('/api/products')
      ]);

      setStats(await statsRes.json());
      setGigs(await gigsRes.json());
      setProducts(await productsRes.json());
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-lg">Loading autonomous income system...</div>
      </div>
    );
  }

  const progressToTarget = ((stats?.monthly_revenue || 0) / 230) * 100;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Autonomous Income System
          </h1>
          <p className="text-gray-600 mt-2">
            Target: $230/month • Current: ${stats?.monthly_revenue.toFixed(2) || '0.00'}
          </p>
        </div>

        {/* Progress Bar */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">
              Progress to Monthly Target
            </span>
            <span className="text-sm font-medium text-gray-900">
              {progressToTarget.toFixed(1)}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div
              className="bg-green-600 h-4 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(progressToTarget, 100)}%` }}
            />
          </div>
          <div className="mt-2 text-xs text-gray-500">
            ${(230 - (stats?.monthly_revenue || 0)).toFixed(2)} to go
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatCard
            title="Total Revenue"
            value={`$${stats?.total_revenue.toFixed(2) || '0.00'}`}
            subtitle="All time"
            color="blue"
          />
          <StatCard
            title="Monthly MRR"
            value={`$${stats?.total_mrr.toFixed(2) || '0.00'}`}
            subtitle="Recurring revenue"
            color="green"
          />
          <StatCard
            title="Profit Margin"
            value={`${stats?.profit_margin.toFixed(1) || '0'}%`}
            subtitle="After AI costs"
            color="purple"
          />
        </div>

        {/* Service Arbitrage Section */}
        <div className="bg-white rounded-lg shadow mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">
              Service Arbitrage Gigs
            </h2>
            <p className="text-sm text-gray-600 mt-1">
              {stats?.active_gigs || 0} active • Fast cash flow
            </p>
          </div>
          <div className="p-6">
            {gigs.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                No gigs yet. System is monitoring Upwork...
              </p>
            ) : (
              <div className="space-y-4">
                {gigs.map((gig) => (
                  <GigCard key={gig.id} gig={gig} />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* SaaS Products Section */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">
              Micro-SaaS Products
            </h2>
            <p className="text-sm text-gray-600 mt-1">
              {stats?.active_products || 0} deployed • Long-term MRR
            </p>
          </div>
          <div className="p-6">
            {products.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                No products yet. System is researching ideas...
              </p>
            ) : (
              <div className="space-y-4">
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  title,
  value,
  subtitle,
  color,
}: {
  title: string;
  value: string;
  subtitle: string;
  color: string;
}) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-700',
    green: 'bg-green-50 text-green-700',
    purple: 'bg-purple-50 text-purple-700',
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="text-sm font-medium text-gray-600 mb-1">{title}</div>
      <div className="text-3xl font-bold text-gray-900 mb-1">{value}</div>
      <div className="text-sm text-gray-500">{subtitle}</div>
    </div>
  );
}

function GigCard({ gig }: { gig: Gig }) {
  const statusColors = {
    discovered: 'bg-gray-100 text-gray-800',
    ready_to_bid: 'bg-yellow-100 text-yellow-800',
    bid_sent: 'bg-blue-100 text-blue-800',
    won: 'bg-green-100 text-green-800',
    delivering: 'bg-purple-100 text-purple-800',
    delivered: 'bg-green-100 text-green-800',
  };

  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <h3 className="font-medium text-gray-900">{gig.title}</h3>
          <div className="flex items-center gap-3 mt-2">
            <span className="text-sm text-gray-600">{gig.platform}</span>
            <span className="text-sm font-medium text-gray-900">
              Up to ${gig.budget_max}
            </span>
          </div>
        </div>
        <span
          className={`px-3 py-1 rounded-full text-xs font-medium ${
            statusColors[gig.status] || statusColors.discovered
          }`}
        >
          {gig.status.replace('_', ' ')}
        </span>
      </div>
    </div>
  );
}

function ProductCard({ product }: { product: Product }) {
  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <h3 className="font-medium text-gray-900">{product.name}</h3>
          <div className="flex items-center gap-4 mt-2">
            <div>
              <div className="text-xs text-gray-600">MRR</div>
              <div className="text-lg font-semibold text-gray-900">
                ${product.mrr.toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-600">Customers</div>
              <div className="text-lg font-semibold text-gray-900">
                {product.customers}
              </div>
            </div>
          </div>
        </div>
        <span
          className={`px-3 py-1 rounded-full text-xs font-medium ${
            product.status === 'deployed'
              ? 'bg-green-100 text-green-800'
              : 'bg-gray-100 text-gray-800'
          }`}
        >
          {product.status}
        </span>
      </div>
    </div>
  );
}
