#!/bin/bash

###############################################################################
# AUTONOMOUS INCOME SYSTEM - ONE-COMMAND DEPLOYMENT
# Deploys complete AI-powered income generation system to VPS
# Target: $230/month through service arbitrage + micro-SaaS
###############################################################################

set -e

echo "🤖 Autonomous Income System - Deployment Starting"
echo "================================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root${NC}" 
   exit 1
fi

echo -e "${YELLOW}Step 1: System Prerequisites${NC}"
echo "Installing Docker, Docker Compose, and dependencies..."

# Update system
apt-get update -qq
apt-get upgrade -y -qq

# Install Docker
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    echo -e "${GREEN}✓ Docker installed${NC}"
else
    echo -e "${GREEN}✓ Docker already installed${NC}"
fi

# Install Docker Compose
if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo -e "${GREEN}✓ Docker Compose installed${NC}"
else
    echo -e "${GREEN}✓ Docker Compose already installed${NC}"
fi

# Install additional tools
apt-get install -y -qq git curl wget nginx certbot python3-certbot-nginx

echo ""
echo -e "${YELLOW}Step 2: Configuration${NC}"

# Check for .env file
if [ ! -f .env ]; then
    echo "Creating .env configuration file..."
    cat > .env << 'EOF'
# Server Configuration
DOMAIN=your-domain.com

# Security
N8N_PASSWORD=$(openssl rand -base64 32)
POSTGRES_PASSWORD=$(openssl rand -base64 32)
NEXTAUTH_SECRET=$(openssl rand -base64 32)

# AI API Keys (REQUIRED - Get these first!)
ANTHROPIC_API_KEY=your_anthropic_key_here
OPENAI_API_KEY=your_openai_key_here
DEEPSEEK_API_KEY=your_deepseek_key_here

# Freelance Platforms (Optional - manual submission works too)
UPWORK_API_KEY=
FIVERR_API_KEY=

# Deployment (Optional - for automated SaaS deployment)
RAILWAY_API_KEY=
VERCEL_TOKEN=
GITHUB_TOKEN=

# Payment Processing (Add when you have customers)
STRIPE_SECRET_KEY=
LEMON_SQUEEZY_API_KEY=
EOF

    echo -e "${RED}⚠ IMPORTANT: Edit .env file with your API keys!${NC}"
    echo ""
    echo "Required API keys:"
    echo "1. Anthropic (Claude) - https://console.anthropic.com"
    echo "2. OpenAI or DeepSeek - https://platform.openai.com or https://platform.deepseek.com"
    echo ""
    echo "Run: nano .env"
    echo "Then re-run this script."
    echo ""
    exit 1
fi

# Load environment
source .env

# Validate required keys
if [ -z "$ANTHROPIC_API_KEY" ] || [ "$ANTHROPIC_API_KEY" = "your_anthropic_key_here" ]; then
    echo -e "${RED}Error: ANTHROPIC_API_KEY not set in .env${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Configuration loaded${NC}"

echo ""
echo -e "${YELLOW}Step 3: Building Services${NC}"

# Create Dockerfiles
mkdir -p services/arbitrage services/saas-builder frontend

# Arbitrage Dockerfile
cat > services/arbitrage/Dockerfile << 'EOF'
FROM python:3.11-slim

WORKDIR /app

RUN pip install --no-cache-dir \
    asyncpg \
    aioredis \
    anthropic \
    httpx \
    feedparser

COPY main.py .

CMD ["python", "main.py"]
EOF

# SaaS Builder Dockerfile  
cat > services/saas-builder/Dockerfile << 'EOF'
FROM python:3.11-slim

WORKDIR /app

RUN pip install --no-cache-dir \
    asyncpg \
    aioredis \
    anthropic \
    httpx \
    gitpython

COPY main.py .

CMD ["python", "main.py"]
EOF

# Frontend Dockerfile
cat > frontend/Dockerfile << 'EOF'
FROM node:20-alpine AS builder

WORKDIR /app

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

FROM node:20-alpine AS runner

WORKDIR /app

ENV NODE_ENV production

COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static

EXPOSE 3000

CMD ["node", "server.js"]
EOF

echo -e "${GREEN}✓ Dockerfiles created${NC}"

echo ""
echo -e "${YELLOW}Step 4: Database Initialization${NC}"

# Start PostgreSQL first
docker-compose up -d postgres
sleep 5

echo -e "${GREEN}✓ Database started${NC}"

echo ""
echo -e "${YELLOW}Step 5: Starting All Services${NC}"

# Start all services
docker-compose up -d

echo -e "${GREEN}✓ All services started${NC}"

echo ""
echo -e "${YELLOW}Step 6: SSL Configuration${NC}"

if [ "$DOMAIN" != "your-domain.com" ]; then
    echo "Setting up SSL for $DOMAIN..."
    
    # Get SSL certificate
    certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN
    
    echo -e "${GREEN}✓ SSL configured${NC}"
else
    echo -e "${YELLOW}⚠ Skipping SSL (no domain configured)${NC}"
fi

echo ""
echo -e "${GREEN}=================================================${NC}"
echo -e "${GREEN}     DEPLOYMENT COMPLETE!${NC}"
echo -e "${GREEN}=================================================${NC}"
echo ""
echo "🎯 System Status:"
echo "   Dashboard: http://$DOMAIN:3000"
echo "   n8n Automation: http://$DOMAIN:5678"
echo ""
echo "📊 Monitor Logs:"
echo "   Service Arbitrage: docker-compose logs -f arbitrage-agent"
echo "   SaaS Builder: docker-compose logs -f saas-builder"
echo "   All Services: docker-compose logs -f"
echo ""
echo "💰 Revenue Target: $230/month"
echo "   Method 1: Service Arbitrage (2-4 months to target)"
echo "   Method 2: Micro-SaaS Products (4-8 months to target)"
echo ""
echo "🔑 Next Steps:"
echo "   1. Visit dashboard to monitor progress"
echo "   2. Check logs to see system working"
echo "   3. Service arbitrage will need manual bid submission"
echo "   4. SaaS ideas will be auto-validated but need manual launch"
echo ""
echo "⚙️ Useful Commands:"
echo "   Stop system: docker-compose down"
echo "   Restart system: docker-compose restart"
echo "   View stats: docker-compose exec postgres psql -U autonomous -d income_system"
echo ""
echo -e "${YELLOW}Remember: This is 85-90% autonomous, not 100%${NC}"
echo "Human review needed for:"
echo "  - Bid submissions (to comply with platform ToS)"
echo "  - Product launches (quality check)"
echo "  - Customer support"
echo ""
echo "Expected time investment: 5-15 hours/week"
echo ""
